import EditPointView from '../view/edit-point-view.js';
import FilterView from '../view/filter-view.js';
import PointView from '../view/point-view.js';
import SortView from '../view/sort-view.js';
import {render} from '../render.js';
import PointsModel from "../model/point-model";

export default class TripPresenter {
  constructor({filtersContainer, eventsContainer}) {
    this.filtersContainer = filtersContainer;
    this.eventsContainer = eventsContainer;
    this.pointsModel = new PointsModel();
  }

  init() {
    this.tripPoints = [...this.pointsModel.getPoints()];
    this.tripDestinations = [...this.pointsModel.getDestinations()];
    // this.defaultPoint = getDefaultPoint();

    // render(new EditPointView({
    //   point: this.defaultPoint,
    //   offers: this.tripOffers[this.defaultPoint.type],
    //   destinations: this.tripDestinations,
    // }), this.eventsContainer);

    render(new SortView(), this.eventsContainer.querySelector('.trip-events__sort-view'));
    render(new FilterView(), this.filtersContainer);

    const tripEventsList = this.eventsContainer.querySelector('.trip-events__list');

    const editPoint = this.tripPoints[6];
    const pointTypes = this.pointsModel.getPointTypes();

    render(new EditPointView({
      point: editPoint,
      pointTypes,
      destinations: this.tripDestinations,
    }), tripEventsList);

    for (let i = 1; i < this.tripPoints.length; i++) {
      render(new PointView({
        point: this.tripPoints[i],
      }), tripEventsList);
    }
  }
}
